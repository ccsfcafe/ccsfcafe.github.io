## CCSF Cafeteria and Chef's Table Website Prototype

By Segev Malool, Nina Bachvarova, Anton Koval, Kelly Bennett, Edward Gee, and Yemane Ogbalidet

